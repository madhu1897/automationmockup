package autoTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import util.util;

public class addToCartXY {
		public static WebDriver driver;
		util config= new util();
		@Test
		public  void addToCartNAssert() throws InterruptedException
		{
			// set Chrome Driver
			System.setProperty("webdriver.chrome.driver", "F:\\ChromeDriver\\chromedriver.exe");
	        WebDriver driver = new ChromeDriver();
			// Goto the site use config to change the URL
	        driver.get(config.siteUrl());
			driver.manage().window().maximize();	
			// Use Search  term and go to listing page
			WebElement searchBox1=driver.findElement(By.xpath(config.searchBox()));	
			searchBox1.sendKeys(config.srchTrm());	
			WebElement searchButton1=driver.findElement(By.xpath(config.searchButton()));
			searchButton1.click();
			// Go to First product add it to cart AND Continue shopping
			driver.get(config.productOnePath());
			WebElement addtoCart1=driver.findElement(By.xpath(config.addToCart()));
			addtoCart1.click();
			// waiting for the pop over
			WebDriverWait explicitWait = new WebDriverWait(driver,10);
			WebElement continueShipping = explicitWait.until(ExpectedConditions.elementToBeClickable(By.xpath(config.continueShopping())));
			continueShipping.click();
			// Go to second product add it to cart and go tocheckout
			driver.get(config.productTwoPath());
			WebElement addtoCart2=driver.findElement(By.xpath(config.addToCart()));
			addtoCart2.click();
			WebElement proceedToCheckout = explicitWait.until(ExpectedConditions.elementToBeClickable(By.xpath(config.proceedToCheckout())));
			proceedToCheckout.click();
			WebElement firstProduct = driver.findElement(By.xpath("//small[contains(text(),'SKU : demo_5')]"));
		 
			WebElement secondProduct= driver.findElement(By.xpath("//small[contains(text(),'SKU : demo_7')]"));
			driver.quit();
		}
		
	}


