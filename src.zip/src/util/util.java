package util;


import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;
import org.testng.annotations.Test;


public class util {
	public Properties pro;
	
	 public util()
	{
		File f1 = new File("filelocation"); // file location of config file
		try
		{
		FileInputStream utfis = new FileInputStream(f1);
		pro = new Properties();
		pro.load(utfis);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
	}
	
	public String siteUrl()
	{
		return (pro.getProperty("siteUrl"));
	}
	
	public String srchTrm()
	{
		return (pro.getProperty("srchTrm"));
	}
	
 

	public  String searchBox() {
		
		return (pro.getProperty("searchBox"));
	}

	public String searchButton() {
		return (pro.getProperty("searchButton"));
	}

	public String productOnePath() {
		
		return (pro.getProperty("productOnePath"));
	}
public String productTwoPath() {
		
		return (pro.getProperty("productTwoPath"));
	}

public String addToCart() {
	
	return (pro.getProperty("addToCart"));
}
public String proceedToCheckout() {
	
	return (pro.getProperty("proceedToCheckout"));
}
public String continueShopping() {
	
	return (pro.getProperty("continueShopping"));
}
}
